/**
 * 
 */
package com.eventizer.entity.common;

import org.springframework.data.annotation.Id;

/**
 * @author shysatya
 *
 */
public class EntityId {
	
	@Id
	private int id;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	

}
