/**
 * 
 */
package com.eventizer.application;

/**
 * @author shysatya
 *
 */
public class EventizerApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
