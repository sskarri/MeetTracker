/**
 * 
 */
package com.eventizer.services.event;

import com.eventizer.entity.common.Event;

/**
 * @author shysatya
 *
 */
interface  EventService {
	
	public void saveEvent(Event event);
	
	public void deleteEvent(int id);
	
	public void updateEvent(Event event);
	
	
	
	
	
	
		
}
