/**
 * 
 */
package com.eventizer.controller.event;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.eventizer.entity.common.CommonUtils;
import com.eventizer.entity.common.Event;
import com.eventizer.entity.common.EventMaster;
import com.eventizer.entity.common.Response;
import com.eventizer.entity.common.SearchCriteria;
import com.eventizer.entity.common.SlotMapper;
import com.eventizer.entity.common.Status;
import com.eventizer.entity.common.StatusDTO;
import com.eventizer.repository.repositories.StatusMaster;
import com.eventizer.services.event.EventMasterService;
import com.eventizer.services.event.EventService;

/**
 * @author shysatya
 *
 */
@RestController
@RequestMapping("/events")
public class EventController {

	public static final Logger logger = LoggerFactory.getLogger(EventController.class);

	@Autowired
	public EventService es;

	@Autowired
	public EventMasterService ems;

	@Autowired
	CommonUtils utils;

	@Autowired
	public StatusMaster stm;

	@RequestMapping(value = "/addEvent", method = RequestMethod.POST)
	public ResponseEntity<Response> createEvent(@Valid @RequestBody Event event, UriComponentsBuilder ucBuilder,
			BindingResult result) throws ParseException {
		logger.info("Creating Event : {}", event);
		if (result.hasErrors()) {
			Response resp = new Response();

			resp.setResult(result.getAllErrors());
			resp.setStatus(false);
			resp.setMessage("Please check the data params");

			return new ResponseEntity<Response>(resp, HttpStatus.BAD_REQUEST);
		}
		long key = event.getMasterKey();
		EventMaster master = ems.getEventMasterById(key);
		if (master != null) {

			logger.info("Verifying...");
			Optional verify = es.findByStartTimeEndTimeAndMasterKey(event.getStartTime(), event.getEndTime(),
					event.getMasterKey());

			if (verify.isPresent()) {
				logger.info("Verified and unavailable...");

				Response resp = new Response();
				resp.setMessage("Event cannot be processed because UnAvailability of " + master.getName()
						+ " Please try again later");
				resp.setResult(Arrays.asList(event));
				resp.setStatus(false);
				return new ResponseEntity<Response>(resp, HttpStatus.CONFLICT);
			}
			logger.info("Event is processing...");

			event.setMaster(master);

			event.setStatus(Status.BOOKED);
			es.addEvent(event);
			logger.info("Event has processed...");

		}
		if (stm.findOne(master.getId()) != null) {
			StatusDTO dto = stm.findOne(master.getId());
			dto.setDate(event.getEventDate());
			dto.setStatus(Status.BOOKED);
			stm.save(dto);
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/events/event/{id}").buildAndExpand(event.getId()).toUri());
		Response resp = new Response();
		resp.setMessage("Event has been Successfully created..!");
		resp.setResult(Arrays.asList(event, headers));
		resp.setStatus(true);
		return new ResponseEntity<Response>(resp, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/getAll", method = RequestMethod.GET)
	public ResponseEntity<Response> getAllEvents() {

		List<Event> events = es.getAllEvents();
		Response resp = new Response();
		resp.setMessage("Events has been successfully retrieved..!");
		resp.setResult(Arrays.asList(events));
		resp.setStatus(true);

		return new ResponseEntity<Response>(resp, HttpStatus.OK);

	}

	@RequestMapping(value = "/getByDate", method = RequestMethod.POST)
	public ResponseEntity<Response> getEventByDate(@RequestBody SlotMapper data) {

		List<Event> events = es.getEventByDate(data.getDate());
		Response resp = new Response();
		resp.setMessage("Events has been successfully retrieved..!");
		resp.setResult(Arrays.asList(events));
		resp.setStatus(true);
		return new ResponseEntity<Response>(resp, HttpStatus.OK);
	}

	@RequestMapping(value = "/getByDateAndTime", method = RequestMethod.POST)
	public ResponseEntity<Response> getEventByDateAndTimeSlot(@RequestBody SlotMapper data) {

		List<Event> events = es.getEventByDateAndTime(data.getDate(), data.getStartTime(), data.getEndTime());
		Response resp = new Response();
		resp.setMessage("Events has been successfully retrieved..!");
		resp.setResult(Arrays.asList(events));
		resp.setStatus(true);
		return new ResponseEntity<Response>(resp, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/searchEvent")

	public List<Event> findAll(@RequestBody SlotMapper data) throws ParseException {
		List<SearchCriteria> params = new ArrayList<SearchCriteria>();
		if (data != null) {
			// Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)(\\w+?),");
			// Matcher matcher = pattern.matcher(search + ",");
			// while (matcher.find()) {
			// params.add(new SearchCriteria(matcher.group(1),
			// matcher.group(2), matcher.group(3)));
			// }
			params.add(new SearchCriteria("eventDate", ":", data.getDate()));

			// params.add(new SearchCriteria("startTime", "<",
			// data.getStartTime()));
			// params.add(new SearchCriteria("endTime", "<",
			// data.getEndTime()));
			// params.add(new SearchCriteria("startTime", ">",
			// formatter(data.getStartTime().toString())));
			// params.add(new SearchCriteria("endTime", ">",
			// formatter(data.getEndTime().toString())));

		}
		return es.searchUser(params);
	}

	@RequestMapping(value = "/getSpecific", method = RequestMethod.POST)
	public ResponseEntity<Response> findByDateWithIntervals(@RequestBody SlotMapper data) throws ParseException {

		List<EventMaster> event = es.findByDateWithIntervals(data.getDate(), data.getEndTime(), data.getStartTime());
		List<EventMaster> events = es.findByStatusQuery(Status.AVAILABLE);

		if (event.isEmpty() && events.isEmpty()) {

			Response resp = new Response();
			resp.setMessage("Event cannot be processed because UnAvailability Please try again with different slot");
			resp.setResult(Arrays.asList(event));
			resp.setStatus(false);
			return new ResponseEntity<Response>(resp, HttpStatus.NOT_FOUND);

		}
		Response resp = new Response();
		resp.setMessage("Events has been successfully retrieved..!");
		resp.setResult(Arrays.asList(event));
		resp.setStatus(true);
		return new ResponseEntity<Response>(resp, HttpStatus.OK);
	}

}
