/**
 * 
 */
package com.eventizer.services.event;

import java.util.List;

import org.springframework.stereotype.Component;

import com.eventizer.entity.common.Event;
import com.eventizer.entity.common.EventMaster;

/**
 * @author shysatya
 *
 */
@Component
public interface EventMasterService {
		
	List<EventMaster> getAllData();
	EventMaster getEventMasterById(long masterId);
     boolean addEventMaster(EventMaster event);
     void updateEventMaster(EventMaster event);
     void deleteEventMaster(int masterId);
	
}
