package com.eventizer.services.event;

import java.text.ParseException; 
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.eventizer.entity.common.Event;
import com.eventizer.entity.common.EventMaster;
import com.eventizer.entity.common.SearchCriteria;
import com.eventizer.entity.common.Status;

@Component
public interface EventService {

	List<Event> getAllEvents();

	Event getEventById(long eventId);

	boolean addEvent(Event event);	

	void updateEvent(Event event);

	void deleteEvent(int EventId);

	List<Event> getEventByDate(Date localDateTime);
	
	List<Event> getEventByDateAndTime(Date date,Date startTime,Date endTime);
	
	 public List<Event> searchUser(List<SearchCriteria> params) throws ParseException;

	List<EventMaster> findByDateWithIntervals(Date date, Date endTime, Date startTime) throws ParseException;
	
	List<EventMaster> findByStatusQuery(Status available);
	
	Optional findByStartTimeEndTimeAndMasterKey(Date startTime,Date endTime,long masterKey) throws ParseException;
	

}
