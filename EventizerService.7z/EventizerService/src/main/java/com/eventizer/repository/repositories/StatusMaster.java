/**
 * 
 */
package com.eventizer.repository.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eventizer.entity.common.StatusDTO;

/**
 * @author shysatya
 *
 */
@Repository
public interface StatusMaster extends JpaRepository<StatusDTO,Long>{
	
	

}
