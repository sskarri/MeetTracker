/**
 * 
 */
package com.eventizer.application;

import static java.time.format.DateTimeFormatter.ofPattern;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.validation.Validator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import com.eventizer.application.config.ResourceBuldlerConfig;
import com.eventizer.entity.common.LocalDateDeserializer;
import com.eventizer.entity.common.LocalDateSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * @author shysatya
 *
 */
@SpringBootApplication(scanBasePackages = { "com.eventizer.*" })
@EnableJpaRepositories(basePackages = "com.eventizer.repository.*")
@CrossOrigin
public class EventizerApplication extends SpringBootServletInitializer
		implements ServletContainerInitializer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(EventizerApplication.class, args);

	}

	@Override
	public void onStartup(Set<Class<?>> arg0, ServletContext arg1) throws ServletException {
		// TODO Auto-generated method stub

	}

	public static final DateTimeFormatter FORMATTER = ofPattern("dd-MM-yyyy HH:MM");

	public static final DateTimeFormatter TIMEFORMATTER = ofPattern("HH:MM");

	/*
	 * @Bean
	 * 
	 * @Primary public ObjectMapper serializingObjectMapper() { ObjectMapper
	 * objectMapper = new ObjectMapper();
	 * 
	 * JavaTimeModule javaTimeModule = new JavaTimeModule();
	 * javaTimeModule.addSerializer(LocalDateTime.class, new
	 * LocalDateSerializer());
	 * javaTimeModule.addDeserializer(LocalDateTime.class, new
	 * LocalDateDeserializer()); objectMapper.registerModule(javaTimeModule);
	 * return objectMapper; }
	 */

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(EventizerApplication.class);
	}
	
	@Bean
	public javax.validation.Validator getValidator() {
		LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
		validator.setValidationMessageSource(ResourceBuldlerConfig.messageSource());
		return validator;
	}


}
